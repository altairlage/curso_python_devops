#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#acesso.py

class Acesso:
	def __init__(self):
		pass
	def acessarConsole(self):
		print "Acesso por VNC"



